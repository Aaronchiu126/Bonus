l=eval(input('Enter the number of layers(2 to 5)='))
sl=eval(input('Enter the side length of the top layer='))
growth=eval(input('Enter the growth of each layer='))
width=eval(input('Enter the trunk width(odd number, 3 to 9)='))
h=eval(input('Enter the trunk height(4 to 10)='))
space=sl+(l-1)*growth-1
print((space)*' '+'#')
f=int(((((1+((sl+(growth*(l-1))-2)*2)+2)-width))/2))
for j in range(1,l+1,1):
	if j>1:
		sl=sl+growth
	for i,w in zip(range(1,sl,1),range(space,0,-1)):   
		if i==sl-1:
			print((w-1)*' '+'#'+(2*i-1)*'#'+'#')
		else:
			print((w-1)*' '+'#'+(2*i-1)*'@'+'#')
for n in range(1,h+1,1):
	print(f*' '+width*'|')
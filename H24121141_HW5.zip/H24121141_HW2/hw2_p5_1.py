n=eval(input('Input an integer number:'))
x=0
x1=0
x2=1
if n==0:
	print('the',str(n)+'-th Fibonacci sequence number:',x)
if n==1:
	print('the',str(n)+'-th Fibonacci sequence number:',x2)
if n > 1:
	for i in range(1,n,1):
		x=x2+x1
		x1=x2
		x2=x
	print('the',str(n)+'-th Fibonacci sequence number:',x)
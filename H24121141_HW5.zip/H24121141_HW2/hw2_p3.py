year=eval(input('Please input year:'))
month=eval(input('Please input month:'))
m=month
d=1
if month==1:
	year=year-1
	m=13
if month==2:
	year=year-1
	m=14
c=year//100
y=year-(c*100)
D=(c//4)-2*c+y+(y//4)+(13*(m+1)//5)+d-1
w=D%7
Date=0
if month==2:
	if (year+1)%4!=0:
		Date=28
	if (year+1)%100==0 and (year+1)%400!=0:
		Date=28
	if (year+1)%4==0 and (year+1)%100!=0:
		Date=29
	if (year+1)%400==0:
		Date=29
if month==1 or month==3 or month==5 or month==7 or month==8 or month==10 or month==12:
	Date=31
elif month==4 or month==6 or month==9 or month==11:
	Date=30
print('Sun Mon Tue Wed Thu Fri Sat')
for i in range(1,Date+1,1):
	if i==1:
		print(w*'    '+' '+'0'+str(i),end=' ')
		w=w+1
		if w>6:
			print()
			w=0
	if i<10 and i>1:
		print(' '+'0'+str(i),end=' ')
		w=w+1
		if w>6:
			print()
			w=0
	elif i>=10:
		print(' '+str(i),end=' ')
		w=w+1
		if w>6:
			print()
			w=0

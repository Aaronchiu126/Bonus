n=eval(input('Input the range number:'))
print('perfect number:')
for i in range(2,n+1,1):
	t=0
	for e in range(1,i,1):
		if i%e==0:
			t=t+e
	if t==i:
		print(t)
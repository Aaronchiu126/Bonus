s=input('Enter a string:')
l=len(s)
a=str()
for i in range(0,l,1):
	for j in range(0,l-i+1,1):
		if l-i>1:
			ns=s[i:l-j]
			sup=ns[::-1]
			if s[i:l-j]==sup:
				if len(sup)>len(a) and len(sup)>1:
					a=sup
print('Longest palindrome substring is:',a)
print('Length is',len(a))
n=eval(input('The number of the requested element in Fibonacci(n):'))
w=input('The plaintext to be encrypted:')
lw=len(w)
x=0
x1=0
x2=1
s1=input('The first string for Palindromic detection (s1):')
s2=input('The first string for Palindromic detection (s2):')
l=len(s1)
a=str()
for i in range(0,l,1):
	for j in range(0,l-i+1,1):
		if l-i>1:
			ns=s1[i:l-j]
			sup=ns[::-1]
			if s1[i:l-j]==sup:
				if len(sup)>len(a) and len(sup)>1:
					a=sup
print('Longest palindrome substring is:',a)
print('Length is',len(a))
l2=len(s2)
a2=str()
for c in range(0,l,1):
	for z in range(0,l2-c+1,1):
		if l-c>1:
			ns2=s2[c:l2-z]
			sup2=ns2[::-1]
			if s2[c:l-z]==sup2:
				if len(sup2)>len(a2) and len(sup2)>1:
					a2=sup2
print('Longest palindrome substring is:',a2)
print('Length is',len(a2))

if n==0:
	print('the',str(n)+'-th Fibonacci sequence number:',x)
if n==1:
	print('the',str(n)+'-th Fibonacci sequence number:',x2)
if n > 1:
	for r in range(1,n,1):
		x=x2+x1
		x1=x2
		x2=x
	print('the',str(n)+'-th Fibonacci sequence number:',x)
for q in range(0,lw,1):
	num=ord(w[q])
	key=(num+x2)*len(a)+len(a2)
	A=((key-65)%26)+65
	FA=chr(A)
	FFA=FA+FA

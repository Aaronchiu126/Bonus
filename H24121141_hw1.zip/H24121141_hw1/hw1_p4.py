h=eval(input('the height of the 1st ball:'))
m1=eval(input('the mass of the 1st ball:'))
m2=eval(input('the mass of the 2nd ball:'))
m1_v=((m1*9.8*h)*2/m1)**(1/2)  #計算m1的初始速度
m2_v=((m2-m1)*0 + 2*m1*m1_v)/(m1+m2)  #計算m2經過碰撞後的速度
print('The velocity of the 1st ball after slide:',m1_v,'m/s')
print('The velocity of the 2nd ball after collision:',m2_v,'m/s')
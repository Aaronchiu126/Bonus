c=299792458
v=eval(input('velocity='))
r=(1/(1-(v**2)/(c**2))**(1/2))
d1=4.3/r  #計算Travel time to Alpha Centauri
d2=6/r    #計算Travel time to Barnard's Star
d3=309/r  #計算Travel time to Betelgeuse (in the Milky Way)
d4=2000000/r  #計算Travel time to Andromeda Galaxy (closest galaxy)
print('Percentage of light speed =',v/c)
print('Travel time to Alpha Centauri = ',d1)
print("Travel time to Barnard's Star =",d2)
print('Travel time to Betelgeuse (in the Milky Way)=',d3)
print('Travel time to Andromeda Galaxy (closest galaxy) = ',d4)
F=eval(input('F='))
G=6.67*(10**-11)
m1=eval(input('The mass of m1='))
r=eval(input('Distance='))
c=299792458
m2=F*(r**2)/(G*m1)  #計算m2的質量
E=m2*(c**2)         #計算E的值
print('The mass of m2=',m2)
print('The energy of m2=',E)